import java.io.*;
import java.util.*;
public class Snail
{
    public static void main(String [] args) throws FileNotFoundException
    {
        int Height;
        int Heightfirst;
        int climbtrack;
        int dayft;
        int nightfall;
        double fat;
        int daycount;
        String line;
        boolean test;

        File file = new File("./Input.txt");
        Scanner filereader = new Scanner(file);
        while(filereader.hasNextLine())
        {
            System.out.println("Hello 4");
            line = filereader.nextLine();
            Scanner linescan = new Scanner(line);
            Height = linescan.nextInt();
            dayft = linescan.nextInt();
            nightfall = linescan.nextInt();
            fat = (double) linescan.nextInt()/100.0;
            climbtrack = 0;
            daycount = 0;
            Heightfirst = Height;
            test = true;
            while(climbtrack < Height)
            {
                System.out.println("hello 3");
                climbtrack = climbtrack + (Height-(Heightfirst* (int) fat*daycount)) - 1;
                if (climbtrack <= 0)
                {
                    test = false;
                }
                daycount++;
            }
            if(test)
            {
                System.out.println("Success on day" + daycount);
            }
            else
            {
                System.out.println("Failure on day" + daycount);
            }
            System.out.println("hello 1");
        }
        System.out.println("hello 2");

    }
}
