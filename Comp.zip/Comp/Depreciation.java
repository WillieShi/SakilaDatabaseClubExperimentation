/**
 * Created by WillieShi on 8/26/2017.
 */
import java.util.*;
public class Depreciation
{
    public static double[][] deprecbymonth;

    public static void main(String[] args)
    {
        int months;
        double down;
        double loanleft;
        double carvalue;
        int numrec;
        int monthcount = 0;

        Scanner console = new Scanner(System.in);
        System.out.print("Gimme the info about your debt");
        String data = console.next();
        Scanner stringbreak = new Scanner(data);
        months = Integer.parseInt(stringbreak.next());
        down = Double.parseDouble(stringbreak.next());
        loanleft = Double.parseDouble(stringbreak.next());
        numrec = Integer.parseInt(stringbreak.next());
        deprecbymonth = new double[months+1][2];
        carvalue = loanleft+500;

        populate(deprecbymonth, numrec, months);

        while(carvalue < loanleft)
        {
            carvalue = carvalue- carvalue*deprecbymonth[2][monthcount];
            loanleft = loanleft - 500;
            System.out.println(carvalue+ " " + loanleft);
            monthcount++;
        }


    }
    public static void populate(double[][] deprecbymonth, int numrec, int months)
    {
        int month;
        double depval;
        int prevmonth = 0;
        double predepval = 0.0;
        String temp;
        Scanner console = new Scanner(System.in);
        for(int i = 0; i< numrec; i++)
        {
            System.out.println("Gimme the" + i + "th datapoint");
            temp = console.next();
            Scanner stringbreak = new Scanner(temp);
            month = Integer.parseInt(stringbreak.next());
            depval = Double.parseDouble(stringbreak.next());
            if(i != 0)
            {
                if(i == numrec-1)
                {
                    for(i = prevmonth; i <= month; i++)
                    {
                        deprecbymonth[2][i] = depval;
                    }
                }

                else
                {
                    for(i = prevmonth; i <= month - prevmonth; i++)
                    {
                        deprecbymonth[2][i] = predepval;
                    }
                }

            }
            prevmonth = month;
            predepval = depval;


        }
    }
}
