import java.util.*;
public class Bronumbers
{
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Onii chan gimme the amount of numbers you wanna input");
        int number = console.nextInt();
        for(int i = 0; i < number)
        {
            String input = console.next();
            if(input.length == 5)
            {
                System.out.println("3");
            }
            else
            {
                if(input.charAt(0) == o)
                {
                    if(input.charAt(1) == w)
                    {
                        if(input.charAt(2) == e)
                        {
                            System.out.println("1")
                        }
                        else
                        {
                            System.out.println("2")
                        }
                    }

                    else if(input.chartAt(1) == n)
                    {
                        System.out.println("1")
                    }
                }
                else
                {
                    if(chartAt(1) == n)
                    {
                        if(charAt(2) == e)
                        {
                            System.out.println("1");
                        }
                        else
                        {
                            System.out.prntln("2");
                        }
                    }

                }
            }
        }
}