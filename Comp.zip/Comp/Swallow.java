import java.util.*;

public class Swallow
{
    public static void main(String[]args)
    {
        int repeattimes;
        int columns;
        String tempinput;
        boolean test = true;
        int gaps = 0;
        int x;
        int y;

        Scanner console = new Scanner(System.in);
        System.out.println("Gimme the repeats");
        repeattimes = console.nextInt();
        console.nextLine();
        System.out.println("Gimme the columns");
        columns = console.nextInt();
        console.nextLine();

        for(int i = 0; i < repeattimes; i++)
        {
            for(int j = 0; j < columns; j++)
            {
                System.out.println("Gimme the column");
                tempinput = console.nextLine();
                Scanner stringbreak = new Scanner(tempinput);
                x = Integer.parseInt(stringbreak.next());
                y = Integer.parseInt(stringbreak.next());
                if(j == 0)
                {
                    gaps = x - y;
                }
                else
                {
                    if(x - y != gaps)
                    {
                        test = false;
                    }
                }
            }
            if(test = true)
            {
                System.out.println("yes");
            }
        }
    }
}
