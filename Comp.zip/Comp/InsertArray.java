/**
 * Created by WillieShi on 9/9/2017.
 */
import java.util.*;
public class InsertArray
{
    public static void main(String []args)
    {
        int[] current = {1,2,3,4};
        int[] newboi = new int[current.length+1];
        int toadd;
        String command;
        Scanner console = new Scanner(System.in);
        System.out.println("Start, end, or index?");
        command = console.next();
        System.out.println("Gimme the number");
        toadd = console.nextInt();
        if(command == "Start")
        {
            for(int i = 0; i < newboi.length; i++)
            {
                if(i == 0)
                {
                    newboi[i] = toadd;
                }
                else
                {
                    newboi[i] = current[i-1];
                }

            }
        }
        else if(command == "end")
        {
            for(int i = 0; i < newboi.length; i++)
            {
                if(i == newboi.length)
                {
                    newboi[i] = toadd;
                }
                else
                {
                    newboi[i] = current[i];
                }

            }
        }
        else if(command == "index")
        {
            int index;
            boolean indexadded = false;
            System.out.println("Gimme the index");
            index = console.nextInt();
            for(int i = 0; i < newboi.length; i++)
            {
                if(indexadded = false)
                {
                    newboi[i] = current[i];
                }
                else if(i == index)
                {
                    newboi[i] = toadd;
                    indexadded = true;
                }
                else if(indexadded = true)
                {
                    newboi[i] = current[i-1];
                }

            }
        }
        System.out.println("OldArray" + Arrays.toString(current));
        System.out.println("NewArray" + Arrays.toString(newboi));
    }

}
