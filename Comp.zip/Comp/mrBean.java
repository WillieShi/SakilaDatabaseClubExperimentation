import java.util.*;

public class mrBean
        {

public static void main(String[] args)
{
        int amount;
        int temp;
        int count = 0;

        String templine;
        System.out.println("Give me the amount of inputs");
        Scanner console = new Scanner(System.in);
        amount = console.nextInt();
        console.nextLine();
        for(int i = 0; i < amount; i++)
        {
            System.out.println("Gimme the input" + (i+1));
            templine = console.nextLine();
            Scanner stringbreak = new Scanner(templine);
            for(int y = 0; y < 3; y++)
            {
                temp = Integer.parseInt(stringbreak.next());
                if(temp > 20 )
                {
                    System.out.println(temp);
                    System.out.println("Case" + (i+1) + "bad");
                    break;
                }
                count++;
            }
            if(count == 3)
            {
                System.out.println("Case" + i+1 + "good");
                count = 0;
            }


        }


}
        }
