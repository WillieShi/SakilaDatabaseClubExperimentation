import jva.util.*;
public class NumberJeopardy
{
    public static void main(String [] args)
    {
        System.out.println("Gimme your Equations");
        Scanner console = new Scanner(System.in);
        String input = console.next();
        System.out.println(input);
    }
}