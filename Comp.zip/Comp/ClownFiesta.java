import java.util.*;
public class ClownFiesta
{
    public static void main(String [] args)
    {
        int max = 0;
        int amttest;
        int amtmon;
        int temp;
        String templine;

        Scanner console = new Scanner(System.in);
        amttest = Integer.parseInt(console.nextLine());
        for(int i = 0; i < amttest; i++)
        {
            templine = console.nextLine();
            Scanner stringbreak = new Scanner(templine);
            while(stringbreak.hasNext())
            {
                temp = Integer.parseInt(stringbreak.next());
                if(max < temp)
                {
                    max = temp;
                }
            }
            System.out.println(max);
            max = 0;
        }
    }
}
